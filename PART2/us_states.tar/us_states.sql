-- MySQL dump 10.13  Distrib 5.6.21, for Linux (i686)
--
-- Host: localhost    Database: us_states
-- ------------------------------------------------------
-- Server version	5.6.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(15) NOT NULL,
  `population` int(11) DEFAULT NULL,
  `crime_rate` enum('low','medium','high') DEFAULT NULL,
  `capital` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states`
--

LOCK TABLES `states` WRITE;
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
INSERT INTO `states` VALUES (1,'mississippi',100,'medium','jackson'),(2,'arkansas',100,'medium','jackson'),(3,'tennessee',50000,'high','memphis'),(4,'new york',500000,'medium','new york'),(5,'alaska',32434,'low','juneau'),(6,'arizona',45464,'low','phoenix'),(7,'california',943735,'medium','sacramento'),(8,'colorado',4123735,'low','denver'),(9,'delaware',43735,'high','dover'),(10,'florida',1143735,'low','tallahassee'),(11,'alabama',374536,'high','montgomery'),(12,'connecticut',548625,'low','hartford'),(13,'georgia',78541,'low','atlanta'),(14,'hawaii',87451,'low','honolulu'),(15,'idaho',874215,'medium','boise'),(16,'illinois',125469,'high','springfield'),(17,'indiana',74841,'medium','indianapolis'),(18,'iowa',458955,'high','des moines'),(19,'kansas',45895,'low','topeka'),(20,'kentucky',362154,'medium','frankfort'),(21,'louisiana',74855,'low','baton rouge'),(22,'maine',45879,'low','augusta'),(23,'maryland',8545,'medium','annapolis'),(24,'michigan',45214,'low','lansing'),(25,'minnesota',4575,'low','saint paul'),(26,'montana',785,'low','helena'),(27,'nebraska',84521,'medium','lincoln'),(28,'nevada',4514,'low','carson city'),(29,'new hampshire',874521,'high','concord'),(30,'new jersey',41254,'high','trenton'),(31,'new mexico',45788,'high','santa fe'),(32,'north carolina',6952,'low','raleigh'),(33,'north dakota',125,'medium','bismarck'),(34,'ohio',874621,'low','columbus'),(35,'oklahoma',74125,'medium','oklahoma city'),(36,'oregon',4585,'high','salem'),(37,'pennsylvania',12546,'low','harrisburg'),(38,'rhode island',87954,'medium','providence'),(39,'south carolina',784,'low','columbia'),(40,'south dakota',451269,'medium','pierre'),(41,'texas',74895,'low','austin'),(42,'utah',4521,'low','salt lake city'),(43,'vermont',54585,'medium','montpelier'),(44,'virginia',784,'low','richmond'),(45,'washington',85415,'high','olympia'),(46,'west virginia',78451,'low','chareston'),(47,'wisconsin',451126,'high','madison'),(48,'wyoming',987654,'medium','cheyenne'),(49,'massachusetts',542145,'high','boston'),(50,'missouri',21587,'low','jefferson city');
/*!40000 ALTER TABLE `states` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-02-06 22:29:34
